print("Name:Utkarsh", "Designation:Faculty")
print("ID:321ABZ", "Password:zzz@123")

