n1=int(input("enter num1"))
n2=int(input("enter num1"))
n3=int(input("enter num1"))
if n2<n1 and n3<n1:
    print("n1 is greater",n1)
elif n1<n2 and n3<n2:
    print("n2 is greater",n2)
else:
    print("n3 is greater",n3)
           
