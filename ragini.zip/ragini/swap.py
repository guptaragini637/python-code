a="abc"
b="def"
c=a
a=b
b=c
print(a,b)
