n=int(input("enter number"))
sum=0
temp=n
while temp!=0:
    d=temp%10
    sum=sum+(d**3)
    temp=temp//10
if n==sum:
    print("number is armstrong")
else:
    print("number is not armstrong")
