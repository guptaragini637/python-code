num=int(input("enter number"))
if num==0:
    print("number is zero")
elif num%2==0:
    print("even number")
else:
    print("odd number")
