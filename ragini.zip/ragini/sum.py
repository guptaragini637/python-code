a=5
b=10
print("sum is",a+b)
