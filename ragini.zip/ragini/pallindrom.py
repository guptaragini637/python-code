num=int(input("enter number"))
n1=num
sum=0
while n1!=0:
    d=n1%10
    sum=(sum*10)+d
    n1=n1//10
if sum==num:
    print("number is pallindrom")
else:
    print("not pallindrom")
